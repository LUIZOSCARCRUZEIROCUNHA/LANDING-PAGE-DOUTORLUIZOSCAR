import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { 
  Heart, 
  Brain, 
  FileText, 
  Users, 
  Shield, 
  Clock,
  CheckCircle2,
  MapPin,
  Phone,
  Mail,
  Stethoscope,
  Award,
  Calendar
} from "lucide-react";

export default function Home() {
  const scrollToContact = () => {
    document.getElementById('contato')?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen flex flex-col bg-background">
      {/* Hero Section */}
      <section className="relative bg-gradient-to-br from-primary/5 via-background to-accent/5 py-20 lg:py-32">
        <div className="container">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <div className="inline-flex items-center gap-2 bg-primary/10 text-primary px-4 py-2 rounded-full text-sm font-medium">
                <Award className="w-4 h-4" />
                CRM-MG 63.132
              </div>
              <h1 className="text-4xl lg:text-6xl font-bold text-foreground leading-tight">
                Dr. Luiz Oscar Cruzeiro Cunha
              </h1>
              <p className="text-xl lg:text-2xl text-muted-foreground font-medium">
                Perícia Médica • Assistência Técnica • Psiquiatria • Medicina de Família
              </p>
              <div className="space-y-3">
                <p className="text-2xl font-semibold text-foreground">
                  Cuidar da mente, do corpo e da verdade: um atendimento humano e técnico.
                </p>
                <p className="text-lg text-muted-foreground">
                  Atendimento médico com empatia, precisão e responsabilidade.
                </p>
              </div>
              <div className="flex flex-col sm:flex-row gap-4 pt-4">
                <Button 
                  size="lg" 
                  className="text-lg px-8 py-6 bg-primary hover:bg-primary/90 text-primary-foreground"
                  asChild
                >
                  <a 
                    href="https://www.doctoralia.com.br/luiz-oscar-cruzeiro-cunha" 
                    target="_blank" 
                    rel="noopener noreferrer"
                  >
                    <Calendar className="w-5 h-5 mr-2" />
                    Agendar pelo Doctoralia
                  </a>
                </Button>
                <Button 
                  size="lg" 
                  variant="outline" 
                  className="text-lg px-8 py-6 border-2"
                  onClick={scrollToContact}
                >
                  Saiba Mais
                </Button>
              </div>
            </div>
            <div className="relative">
              <div className="relative rounded-2xl overflow-hidden shadow-2xl border-4 border-primary/20">
                <img 
                  src="/dr-luiz-oscar.jpg" 
                  alt="Dr. Luiz Oscar Cruzeiro Cunha" 
                  className="w-full h-auto object-cover"
                />
              </div>
              <div className="absolute -bottom-6 -right-6 bg-accent text-accent-foreground px-6 py-4 rounded-xl shadow-lg">
                <p className="text-sm font-semibold">+10 anos</p>
                <p className="text-xs">de experiência</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Sobre o Médico */}
      <section className="py-20 bg-card">
        <div className="container">
          <div className="max-w-4xl mx-auto text-center space-y-6">
            <h2 className="text-3xl lg:text-4xl font-bold text-card-foreground">
              Um médico que entende o paciente — e não apenas a doença
            </h2>
            <div className="h-1 w-24 bg-primary mx-auto rounded-full"></div>
            <p className="text-lg text-muted-foreground leading-relaxed">
              Médico com mais de 10 anos de experiência, formado pela Faculdade de Ciências Médicas e da Saúde de Juiz de Fora . Médico Nuclear formado pelo Hospital de Câncer de Barretos, com especializações em Perícia Médica, Psiquiatria e Medicina de Família. Atua com escuta atenta, linguagem acessível e abordagem baseada em evidências científicas.
            </p>
            <p className="text-lg text-muted-foreground leading-relaxed">
              O compromisso do Dr. Luiz Oscar é oferecer um atendimento que respeita a singularidade de cada paciente, combinando conhecimento técnico com sensibilidade humana. Cada consulta é conduzida com ética, sigilo profissional e dedicação integral ao bem-estar do paciente.
            </p>
          </div>
        </div>
      </section>

      {/* Áreas de Atuação */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground">
              Áreas de Atuação
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Atendimento especializado e integrado para cuidar da sua saúde física e mental
            </p>
          </div>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            <Card className="border-2 hover:border-primary/50 transition-all hover:shadow-lg">
              <CardContent className="p-6 space-y-4">
                <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center">
                  <Brain className="w-7 h-7 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-card-foreground">Psiquiatria</h3>
                <p className="text-muted-foreground">
                  Tratamento de ansiedade, depressão, dependência química, transtornos do sono e outras condições de saúde mental.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-primary/50 transition-all hover:shadow-lg">
              <CardContent className="p-6 space-y-4">
                <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center">
                  <FileText className="w-7 h-7 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-card-foreground">Perícia Médica e Assistência Técnica</h3>
                <p className="text-muted-foreground">
                  Avaliações periciais, assistência técnica , elaboração de laudos e pareceres  médicos de alto valor judicial.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-primary/50 transition-all hover:shadow-lg">
              <CardContent className="p-6 space-y-4">
                <div className="w-14 h-14 bg-primary/10 rounded-xl flex items-center justify-center">
                  <Users className="w-7 h-7 text-primary" />
                </div>
                <h3 className="text-xl font-bold text-card-foreground">Medicina de Família</h3>
                <p className="text-muted-foreground">
                  Cuidados integrados e continuados para toda a família, com foco em prevenção e qualidade de vida.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-primary/50 transition-all hover:shadow-lg">
              <CardContent className="p-6 space-y-4">
                <div className="w-14 h-14 bg-accent/10 rounded-xl flex items-center justify-center">
                  <Stethoscope className="w-7 h-7 text-accent" />
                </div>
                <h3 className="text-xl font-bold text-card-foreground">Avaliações Clínicas</h3>
                <p className="text-muted-foreground">
                  Avaliações médicas detalhadas e elaboração de relatórios para diversas finalidades.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-primary/50 transition-all hover:shadow-lg">
              <CardContent className="p-6 space-y-4">
                <div className="w-14 h-14 bg-accent/10 rounded-xl flex items-center justify-center">
                  <Shield className="w-7 h-7 text-accent" />
                </div>
                <h3 className="text-xl font-bold text-card-foreground">Saúde Preventiva</h3>
                <p className="text-muted-foreground">
                  Orientação e acompanhamento focados na prevenção de doenças e promoção da saúde.
                </p>
              </CardContent>
            </Card>

            <Card className="border-2 hover:border-primary/50 transition-all hover:shadow-lg">
              <CardContent className="p-6 space-y-4">
                <div className="w-14 h-14 bg-accent/10 rounded-xl flex items-center justify-center">
                  <Heart className="w-7 h-7 text-accent" />
                </div>
                <h3 className="text-xl font-bold text-card-foreground">Acompanhamento Contínuo</h3>
                <p className="text-muted-foreground">
                  Cuidado longitudinal com foco no bem-estar integral e na relação médico-paciente.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Como Funciona */}
      <section className="py-20 bg-card">
        <div className="container">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-card-foreground">
              Como Funciona a Consulta
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Processo simples e transparente para seu atendimento
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
            <div className="text-center space-y-4">
              <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto shadow-lg">
                <span className="text-3xl font-bold text-primary-foreground">1</span>
              </div>
              <h3 className="text-xl font-bold text-card-foreground">Agende Online</h3>
              <p className="text-muted-foreground">
                Clique no botão "Agendar pelo Doctoralia" e escolha o melhor horário para você.
              </p>
            </div>
            <div className="text-center space-y-4">
              <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto shadow-lg">
                <span className="text-3xl font-bold text-primary-foreground">2</span>
              </div>
              <h3 className="text-xl font-bold text-card-foreground">Escolha a Modalidade</h3>
              <p className="text-muted-foreground">
                Selecione entre atendimento presencial em Governador Valadares ou consulta online.
              </p>
            </div>
            <div className="text-center space-y-4">
              <div className="w-20 h-20 bg-primary rounded-full flex items-center justify-center mx-auto shadow-lg">
                <span className="text-3xl font-bold text-primary-foreground">3</span>
              </div>
              <h3 className="text-xl font-bold text-card-foreground">Receba Atendimento</h3>
              <p className="text-muted-foreground">
                Tenha uma consulta personalizada, ética e humanizada com total sigilo profissional.
              </p>
            </div>
          </div>
          <div className="mt-12 text-center">
            <div className="inline-flex items-center gap-3 bg-accent/10 text-accent-foreground px-6 py-4 rounded-xl">
              <CheckCircle2 className="w-6 h-6 text-accent" />
              <p className="font-semibold">Atendimento ético, sigiloso e humanizado — presencial ou online</p>
            </div>
          </div>
        </div>
      </section>

      {/* Depoimentos */}
      <section className="py-20 bg-muted/30">
        <div className="container">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-foreground">
              O Que Dizem os Pacientes
            </h2>
            <p className="text-lg text-muted-foreground">
              Avaliações de pacientes atendidos
            </p>
          </div>
          <div className="grid md:grid-cols-2 gap-8 max-w-4xl mx-auto">
            <Card className="border-2">
              <CardContent className="p-8 space-y-4">
                <div className="flex gap-1 text-accent">
                  {[...Array(5)].map((_, i) => (
                    <Heart key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>
                <p className="text-lg text-card-foreground italic">
                  "Profissional atencioso, explica com clareza e transmite segurança. Me senti verdadeiramente acolhido durante toda a consulta."
                </p>
                <p className="text-sm text-muted-foreground font-medium">
                  — Paciente verificado
                </p>
              </CardContent>
            </Card>
            <Card className="border-2">
              <CardContent className="p-8 space-y-4">
                <div className="flex gap-1 text-accent">
                  {[...Array(5)].map((_, i) => (
                    <Heart key={i} className="w-5 h-5 fill-current" />
                  ))}
                </div>
                <p className="text-lg text-card-foreground italic">
                  "Consulta leve e humana, me senti acolhida. O Dr. Luiz Oscar realmente escuta e se importa com o paciente."
                </p>
                <p className="text-sm text-muted-foreground font-medium">
                  — Paciente Doctoralia
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Localização e Contato */}
      <section id="contato" className="py-20 bg-card">
        <div className="container">
          <div className="text-center space-y-4 mb-12">
            <h2 className="text-3xl lg:text-4xl font-bold text-card-foreground">
              Localização e Atendimento
            </h2>
            <p className="text-lg text-muted-foreground">
              Atendimento presencial e online para sua comodidade
            </p>
          </div>
          <div className="grid md:grid-cols-3 gap-8 max-w-4xl mx-auto">
            <Card className="border-2">
              <CardContent className="p-6 text-center space-y-3">
                <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                  <MapPin className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-bold text-lg text-card-foreground">Localização</h3>
                <p className="text-muted-foreground">
                  Governador Valadares – MG
                </p>
              </CardContent>
            </Card>
            <Card className="border-2">
              <CardContent className="p-6 text-center space-y-3">
                <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                  <Clock className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-bold text-lg text-card-foreground">Modalidades</h3>
                <p className="text-muted-foreground">
                  Consultas presenciais e online
                </p>
              </CardContent>
            </Card>
            <Card className="border-2">
              <CardContent className="p-6 text-center space-y-3">
                <div className="w-14 h-14 bg-primary/10 rounded-full flex items-center justify-center mx-auto">
                  <Shield className="w-7 h-7 text-primary" />
                </div>
                <h3 className="font-bold text-lg text-card-foreground">Pagamento</h3>
                <p className="text-muted-foreground">
                  Particular
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* CTA Final */}
      <section className="py-20 bg-gradient-to-br from-primary to-primary/80 text-primary-foreground">
        <div className="container">
          <div className="max-w-3xl mx-auto text-center space-y-8">
            <h2 className="text-3xl lg:text-5xl font-bold">
              Agende sua consulta e cuide da sua saúde com quem entende de verdade
            </h2>
            <p className="text-xl opacity-90">
              Atendimento médico humanizado, ético e baseado em evidências científicas
            </p>
            <Button 
              size="lg" 
              className="text-lg px-10 py-7 bg-white hover:bg-gray-100 text-primary shadow-xl"
              asChild
            >
              <a 
                href="https://www.doctoralia.com.br/luiz-oscar-cruzeiro-cunha" 
                target="_blank" 
                rel="noopener noreferrer"
              >
                <Calendar className="w-6 h-6 mr-2" />
                Agendar pelo Doctoralia
              </a>
            </Button>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="py-8 bg-card border-t">
        <div className="container">
          <div className="text-center space-y-4">
            <p className="text-sm text-muted-foreground">
              Dr. Luiz Oscar Cruzeiro Cunha - CRM-MG 63.132
            </p>
            <p className="text-sm text-muted-foreground">
              Perícia Médica • Assistência Técnica Judicial • Psiquiatria • Medicina de Família • Clínica Médica • Laudos e Pareceres
            </p>
            <p className="text-xs text-muted-foreground">
              Atendimento em conformidade com a Resolução CFM 2.336/2023
            </p>
            <p className="text-xs text-muted-foreground mt-4">
              © {new Date().getFullYear()} Dr. Luiz Oscar Cruzeiro Cunha. Todos os direitos reservados.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
