# Landing Page - Dr. Luiz Oscar Cruzeiro Cunha

Landing page médica profissional desenvolvida para o Dr. Luiz Oscar Cruzeiro Cunha (CRM-MG 63.132), especialista em Perícia Médica, Assistência Técnica Judicial, Psiquiatria e Medicina de Família.

## 🚀 Tecnologias Utilizadas

- **React 19** - Framework JavaScript
- **TypeScript** - Tipagem estática
- **Vite** - Build tool e dev server
- **Tailwind CSS 4** - Framework CSS
- **shadcn/ui** - Componentes UI
- **Wouter** - Roteamento
- **Lucide React** - Ícones

## 📋 Pré-requisitos

Antes de começar, você precisa ter instalado em sua máquina:

- **Node.js** (versão 18 ou superior)
- **pnpm** (gerenciador de pacotes)

### Instalando o pnpm

```bash
npm install -g pnpm
```

## 🔧 Instalação

1. **Extraia o arquivo ZIP** em uma pasta de sua preferência

2. **Navegue até a pasta do projeto**
```bash
cd dr_luiz_oscar_landing
```

3. **Instale as dependências**
```bash
pnpm install
```

## 💻 Executando o Projeto

### Modo de Desenvolvimento

Para iniciar o servidor de desenvolvimento:

```bash
pnpm dev
```

O site estará disponível em: `http://localhost:3000`

### Build para Produção

Para gerar os arquivos otimizados para produção:

```bash
pnpm build
```

Os arquivos serão gerados na pasta `dist/`

### Preview da Build

Para visualizar a versão de produção localmente:

```bash
pnpm preview
```

## 📁 Estrutura do Projeto

```
dr_luiz_oscar_landing/
├── client/                    # Código do frontend
│   ├── public/               # Arquivos estáticos
│   │   └── dr-luiz-oscar.jpg # Foto do médico
│   ├── src/
│   │   ├── components/       # Componentes reutilizáveis
│   │   ├── pages/           # Páginas da aplicação
│   │   │   └── Home.tsx     # Página principal
│   │   ├── contexts/        # Contextos React
│   │   ├── hooks/           # Hooks customizados
│   │   ├── lib/             # Utilitários
│   │   ├── App.tsx          # Componente raiz
│   │   ├── main.tsx         # Entry point
│   │   └── index.css        # Estilos globais
│   └── index.html           # HTML base
├── package.json             # Dependências do projeto
├── vite.config.ts          # Configuração do Vite
├── tailwind.config.ts      # Configuração do Tailwind
└── tsconfig.json           # Configuração do TypeScript
```

## 🎨 Personalização

### Cores

As cores podem ser personalizadas no arquivo `client/src/index.css`:

- **Primary**: Azul petróleo (195 75% 35%)
- **Accent**: Verde suave (150 40% 55%)
- **Background**: Branco
- **Foreground**: Cinza escuro

### Conteúdo

O conteúdo principal está no arquivo `client/src/pages/Home.tsx`. Você pode editar:

- Textos e descrições
- Links do Doctoralia
- Informações de contato
- Áreas de atuação
- Depoimentos

### Imagens

Para substituir a foto do médico:
1. Coloque a nova imagem em `client/public/`
2. Atualize o caminho no arquivo `Home.tsx`

## 🌐 Deploy

### Opções de Hospedagem

A landing page pode ser hospedada em diversas plataformas:

1. **Vercel** (Recomendado)
   - Conecte seu repositório GitHub
   - Deploy automático a cada commit
   - https://vercel.com

2. **Netlify**
   - Suporte a deploy contínuo
   - https://netlify.com

3. **GitHub Pages**
   - Gratuito para repositórios públicos
   - Requer configuração adicional

### Deploy Manual

1. Execute o build:
```bash
pnpm build
```

2. Faça upload da pasta `dist/` para seu servidor web

## 📝 SEO

O site já está otimizado para SEO com:

- Meta tags configuradas
- Descrição otimizada
- Open Graph tags para redes sociais
- Palavras-chave relevantes
- Estrutura semântica HTML5

## 📱 Responsividade

O site é totalmente responsivo e otimizado para:

- Desktop (1920px+)
- Laptop (1024px - 1919px)
- Tablet (768px - 1023px)
- Mobile (320px - 767px)

## 🔒 Conformidade Ética

A landing page está em conformidade com a **Resolução CFM 2.336/2023** sobre publicidade médica, garantindo:

- Linguagem ética e profissional
- Sem promessas de resultados
- Informações verídicas
- Respeito ao sigilo profissional

## 📞 Suporte

Para dúvidas ou suporte técnico, consulte a documentação das tecnologias utilizadas:

- [React](https://react.dev)
- [Vite](https://vitejs.dev)
- [Tailwind CSS](https://tailwindcss.com)
- [shadcn/ui](https://ui.shadcn.com)

## 📄 Licença

Este projeto foi desenvolvido exclusivamente para o Dr. Luiz Oscar Cruzeiro Cunha.

---

**Desenvolvido com ❤️ para profissionais da saúde**
