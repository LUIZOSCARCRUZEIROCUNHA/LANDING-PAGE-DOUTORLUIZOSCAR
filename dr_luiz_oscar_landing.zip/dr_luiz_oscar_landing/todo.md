# Project TODO

[x] Configurar paleta de cores médica (azul petróleo, branco, cinza, verde suave)
[x] Adicionar tipografia Montserrat via Google Fonts
[x] Criar seção Hero com nome, CRM, especialidades e CTA principal
[x] Adicionar foto do Dr. Luiz Oscar na seção Hero
[x] Criar seção "Sobre o médico" com biografia e experiência
[x] Implementar seção "Áreas de atuação" com ícones
[x] Criar seção "Como funciona a consulta" (3 passos)
[x] Adicionar seção de depoimentos de pacientes
[x] Implementar seção de localização e modalidades de atendimento
[x] Criar chamada final (CTA) com botão Doctoralia
[x] Configurar meta tags para SEO
[x] Garantir design responsivo para mobile
[x] Adicionar ícones médicos apropriados
[x] Implementar smooth scroll para navegação
[x] Otimizar imagem do médico

## Atualizações solicitadas pelo usuário

[x] Atualizar formação acadêmica (Faculdade de Ciências Médicas e da Saúde de Juiz de Fora)
[x] Adicionar especialização em Medicina Nuclear (Hospital de Câncer de Barretos)
[x] Alterar "Medicina Legal" para "Perícia Médica e Assistência Técnica"
[x] Atualizar descrição da área de Perícia Médica
[x] Alterar pagamento de "Particular e reembolso médico" para "Particular"
[x] Atualizar especialidades no footer
[x] Corrigir erros ortográficos
[x] Atualizar especialidades no Hero section
